# release-workflow-template — インストールガイド

Claude Code の Workflow tool (dynamic workflows) を使った、リリース単位の開発サイクル (要件壁打ち → 実装 → レビュー → ドキュメント同期 → 検査 → コミット) を、任意のプロジェクトへ導入するためのテンプレート一式です。

Yagura (`/opt/dev/Yagura`) の実運用をそのままプレースホルダー化したものです。抽象的に設計し直したものではないため、置換漏れがあれば動きません。**コピー後、必ず置換 → 動作確認まで行ってください。**

---

## 前提条件

- Claude Code (Workflow tool / dynamic workflows が有効なバージョン)
- 対象プロジェクトが git リポジトリであること (`review-changes` / `sync-docs` が `git diff` を使う)
- 対象プロジェクトに lint / test / build を実行できるコマンドが揃っていること

---

## 同梱物

```
release-workflow-template/
├── README.md                              # 本ファイル (インストールガイド)
├── CLAUDE.md.snippet                      # 対象プロジェクトの CLAUDE.md に追記する運用ルール
└── .claude/
    ├── commands/
    │   ├── refine-requirements.md         # 対話コマンド (要件壁打ち、プレースホルダー置換が必要)
    │   └── logical-commits.md             # 対話コマンド (論理単位コミット、汎用・置換不要)
    └── workflows/
        ├── implement-feature.js           # 探索→設計→実装→検証
        ├── review-changes.js              # 多次元レビュー + 敵対的検証
        ├── sync-docs.js                   # ドキュメント同期
        └── release-check.js               # リリース前検査 (並列)
```

---

## インストール手順

### 1. ファイルをコピーする

対象プロジェクトのルートを `<TARGET>` とする。

```bash
cp -r release-workflow-template/.claude/commands/refine-requirements.md <TARGET>/.claude/commands/
cp -r release-workflow-template/.claude/workflows/*.js <TARGET>/.claude/workflows/
```

`<TARGET>/.claude/commands/` や `<TARGET>/.claude/workflows/` が無ければ先に作成する。既存ファイルと名前が衝突する場合は上書きせず、内容をマージすること。

### 2. プレースホルダーを置換する

コピーした `.claude/workflows/*.js` と `.claude/commands/refine-requirements.md` 内の `{PLACEHOLDER}` をすべて対象プロジェクトの値に置換する。

| プレースホルダー | 説明 | 例 |
|---|---|---|
| `{REPO_PATH}` | 対象プロジェクトの絶対パス | `/opt/dev/SomeOtherProject` |
| `{LINT_CMD}` | Lint コマンド | `pnpm run lint` / `npm run lint` / `ruff check .` |
| `{FORMAT_CHECK_CMD}` | フォーマット確認コマンド | `pnpm run format:check` / `black --check .` |
| `{TEST_CMD}` | テストコマンド | `pnpm run test` / `pytest` / `go test ./...` |
| `{BUILD_CMD}` | ビルドコマンド | `pnpm run build` |
| `{ARCHITECTURE_DOC}` | 設計ドキュメントのパス | `docs/architecture.md` / `docs/ARCHITECTURE.md` |
| `{VAULT_OVERVIEW_PATH}` | (任意) Obsidian 等の外部ノート同期先。使わないなら `sync-docs.js` の該当ブロックごと削除 | `Projects/SomeOtherProject/overview.md` |

置換方法の例 (macOS/BSD sed。GNU sed の場合は `-i` の後の `''` は不要):

```bash
cd <TARGET>
find .claude/commands/refine-requirements.md .claude/workflows -type f \( -name '*.md' -o -name '*.js' \) -print0 \
  | xargs -0 sed -i '' \
    -e 's#{REPO_PATH}#/opt/dev/SomeOtherProject#g' \
    -e 's#{LINT_CMD}#pnpm run lint#g' \
    -e 's#{FORMAT_CHECK_CMD}#pnpm run format:check#g' \
    -e 's#{TEST_CMD}#pnpm run test#g' \
    -e 's#{BUILD_CMD}#pnpm run build#g' \
    -e 's#{ARCHITECTURE_DOC}#docs/architecture.md#g'
```

`review-changes.js` のレビュー観点 (`DIMENSIONS`) は機械的な置換ではなく、プロジェクトの性質を見て手で調整すること (例: フロントエンドが多いなら a11y/i18n、決済を扱うなら compliance など)。

### 2.5 複数言語・複数層のプロジェクト (例: バックエンド+フロントエンド)

このテンプレートは単一スタックの Node/Python/Go プロジェクトだけでなく、Yagura のような Rust+Vue の 2 層構成にも対応できる。上の置換表は「1 スタック分の一例」であり、`{LINT_CMD}` などの単数プレースホルダーに縛られる必要はない:

- **`release-check.js` の `CHECKS` 配列**: 要素数固定ではないただの JS 配列。層/言語ごとに `{ key: 'backend-test', cmd: 'cargo test --workspace' }` のような行を自由に追加・削除してよい (ファイル内にコメントで具体例あり)
- **`review-changes.js` の `DIMENSIONS` 配列**: 同様に、層ごとに観点を分けたい場合は `backend-security` / `frontend-a11y` のようにキーを分けて追加できる
- **`implement-feature.js` / `refine-requirements.md` の `{ARCHITECTURE_DOC}`**: 単一ファイルでも、複数層なら `docs/architecture/backend.md と docs/architecture/frontend.md` のように列挙してよい

つまり `{PLACEHOLDER}` は「最低限これだけ埋めれば動く」ための最小例であり、実際のアーキテクチャに合わせて配列の要素を増減させるのが前提。1 スタックに収まらないプロジェクトほど、置換後にファイルの中身を直接見て調整することを推奨する。

### 3. `CLAUDE.md` に運用ルールを追記する

`CLAUDE.md.snippet` の内容を対象プロジェクトの `CLAUDE.md` 末尾に追記する。既に類似のワークフロー記述がある場合は重複させず統合する。

### 4. ディレクトリを用意する

```bash
mkdir -p <TARGET>/docs/releases
```

### 5. 動作確認

1. Claude Code を対象プロジェクトで起動し、`/refine-requirements release-1 <小さな要件>` を実行 → `docs/releases/release-1/requirements.md` が生成されることを確認
2. `Workflow({name: "release-check"})` を実行し、`.claude/workflows/` からの名前解決と、置換したコマンドが正しく走ることを確認 (最初はここだけ試すのが安全 — 読み取り専用で副作用がない)
3. 問題なければ `Workflow({name: "implement-feature", args: {release: "release-1"}})` で実装フェーズまで通しで試す

---

## トラブルシューティング

| 症状 | 原因 | 対処 |
|---|---|---|
| `Workflow({name: "..."})` が見つからないと言われる | `.claude/workflows/` にファイルが無い、またはファイル名と `meta.name` が不一致 | ファイルの配置場所と `export const meta = { name: '...' }` を確認 |
| 検査コマンドが軒並み失敗する | `{LINT_CMD}` 等の置換漏れ、またはコマンド自体が対象プロジェクトに存在しない | `.claude/workflows/release-check.js` を直接開いて `{PLACEHOLDER}` が残っていないか確認 |
| `review-changes.js` が所見を全く返さない | 対象ブランチ (`base`) の指定ミス、または本当に差分が無い | `args: {base: "..."}` を明示するか `git diff` で差分の有無を確認 |
| `sync-docs.js` の Vault 更新でエラーになる | `{VAULT_OVERVIEW_PATH}` が実在しない、または Vault 連携を使わない | 該当の `agent()` 呼び出しブロックを削除する |

---

## アンインストール

```bash
rm <TARGET>/.claude/commands/refine-requirements.md
rm <TARGET>/.claude/workflows/{implement-feature,review-changes,sync-docs,release-check}.js
```

`CLAUDE.md` に追記した節と `docs/releases/` は手動で判断して削除する (成果物が残っている場合は削除しない方が安全)。

---

## 元ネタ

このテンプレートは `/opt/dev/Yagura` の `docs/release-workflow.md` で運用しているワークフローをそのまま抽出したものです。設計判断の経緯・置換の考え方は同ファイルの「他プロジェクトへの移植」節を参照してください。
